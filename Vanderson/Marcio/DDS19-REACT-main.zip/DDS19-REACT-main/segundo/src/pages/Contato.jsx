import React from 'react'

const Contato = () => {
  return (
    <div>Contato</div>
  )
}

export default Contato