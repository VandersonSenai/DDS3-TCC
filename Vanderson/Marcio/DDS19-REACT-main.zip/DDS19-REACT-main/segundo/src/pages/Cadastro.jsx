import React from "react";
import Forms from "../components/Forms";
import NewForms from "../components/NewForms";

const Cadastro = () => {
  return (
    <div>
      {/* <Forms /> */}
      {/* <Forms nome="Cristiano Ronaldo" email="cr7@thebest.com" senha="goat7" /> */}

      <NewForms />
    </div>
  );
};

export default Cadastro;
