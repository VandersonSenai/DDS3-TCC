import React from "react";

const Contato = () => {
  return (
    <div>
      <h1>Contato</h1>
    </div>
  );
};

export default Contato;
