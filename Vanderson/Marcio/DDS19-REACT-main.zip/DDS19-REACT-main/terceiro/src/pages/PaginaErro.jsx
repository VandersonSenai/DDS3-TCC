
const PaginaErro = () => {
  return (
    <div>
      <h1>Pagina Erro</h1>
    </div>
  );
};

export default PaginaErro;
