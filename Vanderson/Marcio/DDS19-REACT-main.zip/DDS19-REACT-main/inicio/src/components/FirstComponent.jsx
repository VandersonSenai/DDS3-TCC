const FirstComponent = () => {
  return (
   <div>
        <h1>Meu incrível componente</h1>
        <h2>Tá, nem tão incrível assim</h2>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias amet doloribus quos! Saepe placeat totam, ad harum dolor sunt necessitatibus commodi quam deleniti, sint tempore nihil omnis animi molestias suscipit?</p>
        <img src="https://assets.goal.com/images/v3/blt73b1a355d9985def/96afd98cc42e8c71f0c2912b81a6d059a08b7928.jpg?auto=webp&format=pjpg&width=3840&quality=60" />
   </div>
  )
}

export default FirstComponent