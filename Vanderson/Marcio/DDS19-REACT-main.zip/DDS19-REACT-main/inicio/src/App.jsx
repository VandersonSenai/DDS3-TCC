import "./App.css";

import Events from "./components/Events";
import FirstComponent from "./components/FirstComponent";
import Images from "./components/Images";
import MeuCss from "./components/MeuCss";
import MyCss from "./components/MyCss";
import TemplateExpressions from "./components/TemplateExpressions";
import Varia from "./component/Varia";
import ListRender from "./component/ListRender";

function App() {
  return (
    <>
      {/* <TemplateExpressions />
      <hr />
      <FirstComponent /> 
      <Events />
      <h2>Texto incrível</h2>
      <Images /> 
      <p>Texto escrito no App</p>
      <MeuCss />
      <MyCss />
      <Varia />      */}
      <ListRender />
      
    </>
  );
}

export default App;
