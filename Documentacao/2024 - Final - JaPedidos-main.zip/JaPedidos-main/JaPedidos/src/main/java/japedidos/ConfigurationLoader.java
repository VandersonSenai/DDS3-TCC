package japedidos;

import japedidos.bd.ConfigurationFile;

/**
 *
 * @author thiago
 */
public interface ConfigurationLoader {
    public void load(ConfigurationFile source);
}
