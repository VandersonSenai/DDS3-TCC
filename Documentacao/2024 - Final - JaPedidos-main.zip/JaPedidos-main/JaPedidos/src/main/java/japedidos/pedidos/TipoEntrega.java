package japedidos.pedidos;

/**
 *
 * @author thiago
 */
public enum TipoEntrega {
    ENVIO,
    RETIRADA
}
