package japedidos.clientes;

/**
 *
 * @author thiago
 */
public interface InfoAdicionalReceiver {
    public void setInfoAdicionalCliente(Cliente.InfoAdicional info);
}
