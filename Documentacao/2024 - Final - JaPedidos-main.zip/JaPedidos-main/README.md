# JáPedidos
O JáPedidos é um protótipo de sistema de gerenciamento de pedidos.
