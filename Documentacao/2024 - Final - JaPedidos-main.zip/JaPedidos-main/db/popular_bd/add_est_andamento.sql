INSERT INTO est_andamento(id, nome) VALUES 
    (1, "Em aberto"),
    (2, "Aguardando pagamento"),
    (3, "Pago"),
    (4, "Em preparo/separação"),
    (5, "Aguardando envio"),
    (6, "Aguardando retirada"),
    (7, "Saiu para entrega"),
    (8, "Concluído"),
    (9, "Cancelado");
    
